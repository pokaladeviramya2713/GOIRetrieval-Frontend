document.addEventListener('DOMContentLoaded', () => {
    const splashScreen = document.getElementById('splash-screen');
    const mainContent = document.getElementById('main-content');

    // Splash screen logic (only on index.html)
    if (splashScreen) {
        setTimeout(() => {
            splashScreen.style.transition = 'opacity 0.8s ease-out';
            splashScreen.style.opacity = '0';
            setTimeout(() => {
                splashScreen.classList.add('hidden');
                if (mainContent) {
                    mainContent.classList.remove('hidden');
                    mainContent.style.animation = 'fadeIn 1s ease-in forwards';
                }
            }, 800);
        }, 3000);
    }

    // Page Detection
    if (document.body.classList.contains('dashboard-body')) {
        if (document.body.classList.contains('search-page')) {
            initSearch();
        } else if (document.body.classList.contains('reports-page')) {
            initReports();
        } else if (document.body.classList.contains('browse-page')) {
            initBrowse();
        } else if (document.body.classList.contains('article-page')) {
            initArticle();
        } else if (document.body.classList.contains('assistant-page')) {
            initChatbot();
        } else if (document.body.classList.contains('audit-page')) {
            initAudit();
        } else if (document.body.classList.contains('profile-page')) {
            initProfile();
        } else if (document.body.classList.contains('personal-info-page')) {
            initPersonalInfo();
        } else if (document.body.classList.contains('role-permissions-page')) {
            initRolePermissions();
        } else if (document.body.classList.contains('preferences-page')) {
            initPreferences();
        } else if (document.body.classList.contains('security-settings-page')) {
            initSecuritySettings();
        } else if (document.body.classList.contains('privacy-settings-page')) {
            initPrivacySettings();
        } else if (document.body.classList.contains('notifications-page')) {
            initNotificationsSettings();
        } else {
            initDashboard();
        }
    } else if (document.body.classList.contains('auth-page')) {
        if (document.getElementById('login-form')) initLogin();
        else if (document.getElementById('signup-form')) initSignup();
        else if (document.getElementById('forgot-password-form')) initForgotPassword();
    }
});

// --- Configuration ---
const API_BASE_URL = 'http://180.235.121.253:8165';
const USER_ID = 1;

// --- Helper Functions ---
function getInitials(name) {
    if (!name) return "A";
    const trimmed = name.trim();
    return trimmed.length > 0 ? trimmed[0].toUpperCase() : "A";
}

// --- Dashboard Logic ---
async function initDashboard() {
    console.log("[DB] Initializing Dashboard...");
    updateDateTime();
    fetchStats();
    fetchTrends();
    fetchActivities();
}

function updateDateTime() {
    const dateEl = document.getElementById('current-date');
    if (dateEl) {
        const now = new Date();
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        dateEl.innerText = now.toLocaleDateString('en-US', options);
    }
}

async function fetchStats() {
    try {
        const response = await fetch(`${API_BASE_URL}/stats?user_id=${USER_ID}`);
        const data = await response.json();
        if (data.status === 'success') {
            document.getElementById('stat-docs').innerText = data.total_documents || '0';
            document.getElementById('stat-ai').innerText = data.total_ai_queries || '0';
            document.getElementById('stat-users').innerText = data.total_users || '0';
        }
    } catch (error) {
        console.error("Error fetching stats:", error);
    }
}

async function fetchTrends() {
    try {
        const response = await fetch(`${API_BASE_URL}/audit_trends/${USER_ID}`);
        const data = await response.json();
        if (data.status === 'success') {
            renderTrendsGraph(data.labels, data.counts);
        }
    } catch (error) {
        console.error("Error fetching trends:", error);
        renderTrendsGraph(['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'], [12, 19, 3, 5, 2, 3, 7]);
    }
}

function renderTrendsGraph(labels, counts) {
    const svg = document.getElementById('trend-graph');
    const path = document.getElementById('graph-path');
    const fill = document.getElementById('graph-fill');
    const labelContainer = document.getElementById('graph-labels');
    
    if (!svg || !path || !labels || !counts) return;

    // Clear existing circles
    const existingCircles = svg.querySelectorAll('.data-point');
    existingCircles.forEach(c => c.remove());

    const width = 800;
    const height = 250;
    const padding = 40;
    const maxVal = Math.max(...counts, 10);
    
    const points = counts.map((val, i) => {
        const x = padding + (i * (width - 2 * padding) / (labels.length - 1));
        const y = height - padding - (val / maxVal * (height - 2 * padding));
        return { x, y, value: val, label: labels[i] };
    });

    let d = `M ${points[0].x} ${points[0].y}`;
    for (let i = 1; i < points.length; i++) {
        const cp1x = points[i-1].x + (points[i].x - points[i-1].x) / 2;
        d += ` C ${cp1x} ${points[i-1].y}, ${cp1x} ${points[i].y}, ${points[i].x} ${points[i].y}`;
    }
    path.setAttribute('d', d);
    
    const fillD = `${d} L ${points[points.length-1].x} ${height - padding} L ${points[0].x} ${height - padding} Z`;
    fill.setAttribute('d', fillD);

    let tooltip = document.getElementById('graph-tooltip');
    if (!tooltip) {
        tooltip = document.createElement('div');
        tooltip.id = 'graph-tooltip';
        tooltip.className = 'graph-tooltip';
        document.body.appendChild(tooltip);
    }

    points.forEach((p, i) => {
        const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
        circle.setAttribute("cx", p.x);
        circle.setAttribute("cy", p.y);
        circle.setAttribute("r", "6");
        circle.setAttribute("class", "data-point");
        circle.setAttribute("fill", "white");
        circle.setAttribute("stroke", "var(--primary)");
        circle.setAttribute("stroke-width", "3");
        
        circle.addEventListener('mouseenter', (e) => {
            circle.setAttribute("r", "8");
            circle.setAttribute("fill", "var(--primary)");
            circle.setAttribute("stroke", "white");
            tooltip.innerHTML = `<strong>${p.value} Audits</strong><br>${p.label}`;
            tooltip.style.display = 'block';
            const rect = e.target.getBoundingClientRect();
            tooltip.style.left = `${rect.left + window.scrollX - tooltip.offsetWidth / 2}px`;
            tooltip.style.top = `${rect.top + window.scrollY - 45}px`;
        });

        circle.addEventListener('mouseleave', () => {
            circle.setAttribute("r", "6");
            circle.setAttribute("fill", "white");
            circle.setAttribute("stroke", "var(--primary)");
            tooltip.style.display = 'none';
        });

        svg.appendChild(circle);
    });

    labelContainer.innerHTML = '';
    labels.forEach(label => {
        const span = document.createElement('span');
        span.innerText = label;
        labelContainer.appendChild(span);
    });
}

async function fetchActivities() {
    const list = document.getElementById('activity-list');
    if (!list) return;

    try {
        const response = await fetch(`${API_BASE_URL}/activities/${USER_ID}`);
        const data = await response.json();
        if (data.status === 'success' && data.activities.length > 0) {
            list.innerHTML = '';
            data.activities.slice(0, 5).forEach(act => {
                const li = document.createElement('li');
                li.className = 'activity-item';
                let iconColor = 'rgba(26, 27, 75, 0.1)';
                let iconSvg = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>';
                if (act.type.includes('Audit')) {
                    iconColor = 'rgba(46, 125, 50, 0.1)';
                    iconSvg = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>';
                } else if (act.type.includes('Chat')) {
                    iconColor = 'rgba(147, 51, 234, 0.1)';
                    iconSvg = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>';
                }
                li.innerHTML = `
                    <div class="activity-icon" style="background: ${iconColor}">
                        ${iconSvg}
                    </div>
                    <div class="activity-info">
                        <h4>${act.type}</h4>
                        <p>${act.detail}</p>
                    </div>
                    <span class="activity-time">${act.time}</span>
                `;
                list.appendChild(li);
            });
        } else {
            list.innerHTML = '<li class="activity-item">No recent activity found.</li>';
        }
    } catch (error) {
        console.error("Error fetching activities:", error);
    }
}

// --- Search Logic ---
let allDocs = [];

async function initSearch() {
    console.log("[Search] Initializing Search Page...");
    
    // 1. Initial document fetch (All)
    fetchDocuments('All');

    // 2. Setup Category Chips
    const chips = document.querySelectorAll('.chip');
    chips.forEach(chip => {
        chip.addEventListener('click', () => {
            chips.forEach(c => c.classList.remove('active'));
            chip.classList.add('active');
            fetchDocuments(chip.dataset.cat);
        });
    });

    // 3. Setup Live Search Input
    const searchInput = document.getElementById('search-docs-input');
    let debounceTimer;
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(() => {
                const query = e.target.value.trim();
                if (query.length > 2) {
                    performSearch(query);
                } else if (query.length === 0) {
                    fetchDocuments('All');
                }
            }, 500);
        });
    }
}

async function fetchDocuments(category) {
    const grid = document.getElementById('doc-grid');
    if (!grid) return;
    grid.innerHTML = '<div class="loading-state">Loading documents...</div>';
    
    try {
        const response = await fetch(`${API_BASE_URL}/documents?category=${category}&user_id=${USER_ID}`);
        const data = await response.json();
        if (data.status === 'success') {
            renderDocumentCards(data.documents);
            const countEl = document.getElementById('results-count');
            if (countEl) countEl.innerText = `Results found: ${data.documents.length}`;
        }
    } catch (error) {
        console.error("Error fetching documents:", error);
        grid.innerHTML = '<div class="loading-state">Error loading documents. Please ensure the backend is running.</div>';
    }
}

async function performSearch(query) {
    const grid = document.getElementById('doc-grid');
    if (!grid) return;
    grid.innerHTML = '<div class="loading-state">Searching...</div>';
    
    try {
        const response = await fetch(`${API_BASE_URL}/search?q=${encodeURIComponent(query)}`);
        const data = await response.json();
        if (data.status === 'success') {
            renderDocumentCards(data.documents);
            const countEl = document.getElementById('results-count');
            if (countEl) countEl.innerText = `Search results for "${query}": ${data.documents.length}`;
        }
    } catch (error) {
        console.error("Error performing search:", error);
    }
}

// --- Reports Logic ---
async function initReports() {
    console.log("[Reports] Initializing Reports Page...");
    
    // 1. Initial reports fetch
    fetchDocuments('Reports');

    // 2. Setup Live Search Input for Reports
    const searchInput = document.getElementById('search-reports-input');
    if (searchInput) {
        let debounceTimer;
        searchInput.addEventListener('input', (e) => {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(() => {
                const query = e.target.value.trim();
                if (query.length > 2) {
                    performReportsSearch(query);
                } else if (query.length === 0) {
                    fetchDocuments('Reports');
                }
            }, 500);
        });
    }
}

async function performReportsSearch(query) {
    const grid = document.getElementById('doc-grid');
    if (!grid) return;
    grid.innerHTML = '<div class="loading-state">Searching reports...</div>';
    
    try {
        const response = await fetch(`${API_BASE_URL}/documents?category=Reports&user_id=${USER_ID}`);
        const data = await response.json();
        if (data.status === 'success') {
            const filtered = data.documents.filter(doc => 
                doc.title.toLowerCase().includes(query.toLowerCase()) || 
                (doc.description && doc.description.toLowerCase().includes(query.toLowerCase()))
            );
            renderDocumentCards(filtered);
            const countEl = document.getElementById('results-count');
            if (countEl) countEl.innerText = `Search results for "${query}": ${filtered.length}`;
        }
    } catch (error) {
        console.error("Error performing reports search:", error);
    }
}

// --- Browse Docs Logic ---
const STORAGE_KEYS = {
    RECENT: `recent_docs_${USER_ID}`,
    SAVED: `saved_docs_${USER_ID}`
};

function initBrowse() {
    console.log("[Browse] Initializing Browse Docs Page...");
    renderBrowseSections();
}

function renderBrowseSections() {
    const recentGrid = document.getElementById('recent-grid');
    const savedGrid = document.getElementById('saved-grid');
    
    if (recentGrid) {
        const recentDocs = getStoredDocs(STORAGE_KEYS.RECENT);
        renderDocsInGrid(recentDocs, recentGrid, "No recently opened documents.");
    }
    
    if (savedGrid) {
        const savedDocs = getStoredDocs(STORAGE_KEYS.SAVED);
        renderDocsInGrid(savedDocs, savedGrid, "No saved documents yet.");
    }
}

function renderDocsInGrid(docs, grid, emptyMsg) {
    grid.innerHTML = '';
    if (!docs || docs.length === 0) {
        grid.innerHTML = `<div class="loading-state">${emptyMsg}</div>`;
        return;
    }
    
    docs.forEach(doc => {
        const card = createDocCard(doc);
        grid.appendChild(card);
    });
}

function getStoredDocs(key) {
    const stored = localStorage.getItem(key);
    return stored ? JSON.parse(stored) : [];
}

function addToRecent(doc) {
    let recent = getStoredDocs(STORAGE_KEYS.RECENT);
    recent = recent.filter(d => d.id !== doc.id);
    recent.unshift(doc);
    recent = recent.slice(0, 12);
    localStorage.setItem(STORAGE_KEYS.RECENT, JSON.stringify(recent));
}

function toggleSave(doc, iconBtn) {
    let saved = getStoredDocs(STORAGE_KEYS.SAVED);
    const isSaved = saved.some(d => d.id === doc.id);
    
    if (isSaved) {
        saved = saved.filter(d => d.id !== doc.id);
        if (iconBtn) iconBtn.classList.remove('active');
    } else {
        saved.unshift(doc);
        if (iconBtn) iconBtn.classList.add('active');
    }
    
    localStorage.setItem(STORAGE_KEYS.SAVED, JSON.stringify(saved));
    
    if (document.body.classList.contains('browse-page')) {
        renderBrowseSections();
    }
}

function renderDocumentCards(documents) {
    const grid = document.getElementById('doc-grid');
    if (!grid) return;
    grid.innerHTML = '';

    let filteredDocs = documents;
    if (document.body.classList.contains('search-page')) {
        filteredDocs = documents.filter(doc => (doc.category || '').toLowerCase() !== 'reports');
    }

    if (filteredDocs.length === 0) {
        grid.innerHTML = '<div class="loading-state">No documents found matching your criteria.</div>';
        return;
    }

    filteredDocs.forEach(doc => {
        const card = createDocCard(doc);
        grid.appendChild(card);
    });
}

function createDocCard(doc) {
    const card = document.createElement('div');
    card.className = 'doc-card';
    
    const date = doc.date || '2025-03-01';
    const excerpt = doc.excerpt || doc.description || 'Official government document.';
    
    const saved = getStoredDocs(STORAGE_KEYS.SAVED);
    const isSaved = saved.some(d => d.id === doc.id);

    card.innerHTML = `
        <div class="doc-card-inner">
            <div class="doc-card-header">
                <span class="doc-type-tag">${doc.category || 'Policy'}</span>
                <div class="card-actions-top">
                    <span class="doc-date">${date}</span>
                    <button class="btn-save-doc ${isSaved ? 'active' : ''}" title="Save Document">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="${isSaved ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path></svg>
                    </button>
                </div>
            </div>
            <h3 class="doc-title">${doc.title}</h3>
            <p class="doc-excerpt">${excerpt}</p>
        </div>
        <div class="doc-card-footer">
            <span class="doc-dept">${doc.department || 'Education Ministry'}</span>
            <a href="article.html?id=${doc.id}" class="btn-view-doc">
                <span>View Docs</span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14"></path><polyline points="12 5 19 12 12 19"></polyline></svg>
            </a>
        </div>
    `;

    const saveBtn = card.querySelector('.btn-save-doc');
    saveBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        toggleSave(doc, saveBtn);
        const svgPath = saveBtn.querySelector('svg');
        if (saveBtn.classList.contains('active')) {
            svgPath.setAttribute('fill', 'currentColor');
        } else {
            svgPath.setAttribute('fill', 'none');
        }
    });

    const viewBtn = card.querySelector('.btn-view-doc');
    viewBtn.addEventListener('click', (e) => {
        addToRecent(doc);
    });

    return card;
}

// --- Article View Logic ---
async function initArticle() {
    const params = new URLSearchParams(window.location.search);
    const docId = params.get('id');
    
    if (!docId) {
        window.location.href = 'search.html';
        return;
    }

    console.log(`[Article] Loading document: ${docId}`);
    
    try {
        const response = await fetch(`${API_BASE_URL}/document/${docId}?user_id=${USER_ID}`);
        const data = await response.json();
        
        if (data.status === 'success' && data.document) {
            renderArticle(data.document);
            addToRecent(data.document);
        } else {
            const container = document.getElementById('article-body');
            container.innerHTML = '<div class="loading-state">Document not found. It may have been removed or moved.</div>';
        }
    } catch (error) {
        console.error("Error fetching article:", error);
        const container = document.getElementById('article-body');
        container.innerHTML = '<div class="loading-state">Error connecting to the server.</div>';
    }
}

function renderArticle(doc) {
    const breadcrumb = document.getElementById('breadcrumb-title');
    if (breadcrumb) breadcrumb.innerText = doc.title;
    
    const title = document.getElementById('article-title');
    if (title) title.innerText = doc.title;
    
    const cat = document.getElementById('article-category');
    if (cat) cat.innerText = doc.category || 'Policy';
    
    const dept = document.getElementById('article-dept');
    if (dept) dept.innerText = doc.department || 'Ministry of Education';
    
    const date = document.getElementById('article-date');
    if (date) date.innerText = doc.date || '2025-03-13';
    
    const body = document.getElementById('article-body');
    if (!body) return;

    const content = doc.content || "No content available for this document.";
    const isExtracted = content.includes('\n') || doc.format === 'PDF';
    
    if (isExtracted) {
        body.innerHTML = `
            <div class="article-inner">
                <div class="article-extracted-content">
                    <pre style="white-space: pre-wrap; font-family: inherit; line-height: 1.8; color: #334155;">${content}</pre>
                </div>
            </div>
        `;
    } else {
        const formattedContent = content.split('\n').map(p => p.trim() ? `<p>${p}</p>` : '').join('');
        body.innerHTML = `<div class="article-inner"><div class="article-introduction">${formattedContent}</div></div>`;
    }

    const saveBtn = document.getElementById('btn-save-article');
    if (saveBtn) {
        const saved = getStoredDocs(STORAGE_KEYS.SAVED);
        const isSaved = saved.some(d => d.id === doc.id);
        if (isSaved) saveBtn.classList.add('active');
        
        saveBtn.addEventListener('click', () => {
            toggleSave(doc, saveBtn);
            const svgPath = saveBtn.querySelector('svg');
            if (saveBtn.classList.contains('active')) {
                svgPath.setAttribute('fill', 'currentColor');
                saveBtn.querySelector('span').innerText = 'Saved';
            } else {
                svgPath.setAttribute('fill', 'none');
                saveBtn.querySelector('span').innerText = 'Save';
            }
        });
    }
}

// --- AI Assistant (Chatbot) Logic ---
const CHAT_STORAGE_KEY = 'goi_chat_history';

function initChatbot() {
    console.log("[AI] Initializing Chatbot...");
    const chatMessages = document.getElementById('chat-messages');
    const chatForm = document.getElementById('chat-form');
    const chatInput = document.getElementById('chat-input');
    const typingIndicator = document.getElementById('typing-indicator');
    const welcomeState = document.getElementById('chat-welcome');

    if (!chatMessages) return;

    const history = JSON.parse(localStorage.getItem(CHAT_STORAGE_KEY) || '[]');
    if (history.length > 0) {
        if (welcomeState) welcomeState.style.display = 'none';
        history.forEach(msg => appendMessage(msg.text, msg.sender, false));
    }

    if (chatForm) {
        chatForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const message = chatInput.value.trim();
            if (!message) return;

            chatInput.value = '';
            if (welcomeState) welcomeState.style.display = 'none';

            appendMessage(message, 'user');
            saveToHistory(message, 'user');

            if (typingIndicator) {
                typingIndicator.style.display = 'block';
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }

            try {
                const response = await fetch(`${API_BASE_URL}/chatbot`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ user_id: USER_ID, message: message })
                });
                
                const data = await response.json();
                if (typingIndicator) typingIndicator.style.display = 'none';

                if (data.status === 'success') {
                    appendMessage(data.message, 'ai');
                    saveToHistory(data.message, 'ai');
                } else {
                    const fallbackMsg = "I'm sorry, I'm having trouble connecting to my central knowledge base. Please try again in a moment.";
                    const errorMsg = data.message ? `<b>AI Assistant Error:</b><br>${data.message}` : fallbackMsg;
                    appendMessage(errorMsg, 'ai');
                }
            } catch (error) {
                console.error("Chatbot error:", error);
                if (typingIndicator) typingIndicator.style.display = 'none';
                appendMessage("An error occurred while trying to reach the Ministry of Education servers. Please check your connection.", 'ai');
            }
        });
    }

    function appendMessage(text, sender, animate = true) {
        const bubble = document.createElement('div');
        bubble.className = `message-bubble ${sender}-message`;
        if (!animate) bubble.style.animation = 'none';
        bubble.innerHTML = text;
        
        const now = new Date();
        const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const timeSpan = document.createElement('span');
        timeSpan.className = 'chat-timestamp';
        timeSpan.innerText = timeStr;
        bubble.appendChild(timeSpan);
        
        chatMessages.appendChild(bubble);
        setTimeout(() => {
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }, 10);
    }

    function saveToHistory(text, sender) {
        const history = JSON.parse(localStorage.getItem(CHAT_STORAGE_KEY) || '[]');
        history.push({ text, sender, timestamp: new Date().toISOString() });
        if (history.length > 50) history.shift();
        localStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(history));
    }
}

// --- AI Audit Logic ---
function initAudit() {
    console.log("[AUDIT] Initializing AI Audit Portal...");
    const modeCards = document.querySelectorAll('.audit-mode-card');
    const runBtn = document.getElementById('btn-run-audit');
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('audit-files');
    const fileStatus = document.getElementById('file-status');
    const questionsInput = document.getElementById('audit-questions');
    const loadingArea = document.getElementById('audit-loading');
    const resultsArea = document.getElementById('audit-results');
    const summaryText = document.getElementById('system-summary');
    const resultsGrid = document.getElementById('doc-analysis-results');

    let selectedMode = 'SCENARIO';

    modeCards.forEach(card => {
        card.addEventListener('click', () => {
            modeCards.forEach(c => c.classList.remove('active'));
            card.classList.add('active');
            selectedMode = card.getAttribute('data-mode');
        });
    });

    if (dropZone) {
        dropZone.addEventListener('click', () => fileInput.click());
        dropZone.addEventListener('dragover', (e) => { e.preventDefault(); dropZone.classList.add('dragover'); });
        dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('dragover');
            fileInput.files = e.dataTransfer.files;
            updateFileStatus();
        });
    }

    if (fileInput) fileInput.addEventListener('change', updateFileStatus);

    function updateFileStatus() {
        if (!fileInput) return;
        const count = fileInput.files.length;
        fileStatus.innerText = count > 0 ? `${count} file(s) selected.` : "Drag and drop regulatory PDF or ZIP files here, or click to browse";
    }

    if (runBtn) {
        runBtn.addEventListener('click', async () => {
            if (fileInput.files.length === 0) {
                alert("Please select at least one regulatory document to audit.");
                return;
            }

            loadingArea.style.display = 'flex';
            resultsArea.classList.add('hidden');
            runBtn.disabled = true;
            runBtn.innerHTML = "Auditing Departmental Files...";

            const formData = new FormData();
            formData.append('user_id', USER_ID);
            formData.append('mode', selectedMode);
            formData.append('questions', questionsInput.value.trim());
            for (let i = 0; i < fileInput.files.length; i++) {
                formData.append('files', fileInput.files[i]);
            }

            try {
                const response = await fetch(`${API_BASE_URL}/ai_audit_bulk`, {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();
                if (data.status === 'success') {
                    renderAuditResults(data.system_audit_summary, data.documents);
                } else {
                    alert("Audit Failed: " + data.message);
                }
            } catch (error) {
                console.error("Audit error:", error);
                alert("An error occurred during regulatory analysis.");
            } finally {
                loadingArea.style.display = 'none';
                runBtn.disabled = false;
                runBtn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg> Execute AI Audit';
            }
        });
    }
}

function renderAuditResults(summary, documents) {
    const summaryText = document.getElementById('system-summary');
    const resultsGrid = document.getElementById('doc-analysis-results');
    const resultsArea = document.getElementById('audit-results');
    if (!resultsArea) return;

    resultsArea.classList.remove('hidden');
    if (summaryText) summaryText.innerHTML = summary;
    if (resultsGrid) {
        resultsGrid.innerHTML = '';
        if (documents && documents.length > 0) {
            documents.forEach(doc => {
                const scoreClass = doc.compliance_score >= 80 ? 'high' : (doc.compliance_score >= 50 ? 'medium' : 'low');
                const riskLabel = doc.compliance_score >= 80 ? 'Low Risk' : (doc.compliance_score >= 50 ? 'Medium Risk' : 'Critical Conflict');
                const card = document.createElement('div');
                card.className = 'doc-analysis-card';
                card.innerHTML = `
                    <div class="compliance-badge compliance-${scoreClass}">${doc.compliance_score}% - ${riskLabel}</div>
                    <h3>${doc.title}</h3>
                    <p><b>Executive Summary:</b> ${doc.summary}</p>
                    <p style="margin-top: 15px;"><b>AI Analysis:</b> ${doc.ai_analysis}</p>
                `;
                resultsGrid.appendChild(card);
            });
        }
    }
    setTimeout(() => { resultsArea.scrollIntoView({ behavior: 'smooth' }); }, 100);
}

// --- Profile Logic ---
function initProfile() {
    console.log("[Profile] Initializing Profile Page...");
    updateDateTime();
    
    const storedUser = JSON.parse(localStorage.getItem('user')) || {};
    const defaultUser = {
        name: storedUser.name || "Admin Sharma",
        role: storedUser.role || storedUser.title || "Senior Administrator"
    };

    const nameDisplay = document.getElementById('profile-name-display');
    const titleDisplay = document.getElementById('profile-title-display');
    const avatarDisplay = document.getElementById('profile-avatar');
    
    if (nameDisplay) nameDisplay.innerText = defaultUser.name;
    if (titleDisplay) titleDisplay.innerText = defaultUser.role;
    if (avatarDisplay) avatarDisplay.innerText = getInitials(defaultUser.name);
}

/* --- Personal Info Page Logic --- */
async function initPersonalInfo() {
    console.log("[PI] Initializing Personal Info...");
    const storedUser = JSON.parse(localStorage.getItem('user')) || {};
    
    const defaultUser = {
        name: storedUser.name || "Admin Sharma",
        email: storedUser.email || "admin.sharma@education.gov.in",
        role: storedUser.role || "Senior Administrator",
        employeeId: storedUser.employeeId || "GOI-78291"
    };

    const nameEl = document.getElementById('display-name');
    const roleEl = document.getElementById('display-role');
    const avatarEl = document.getElementById('personal-avatar');
    const inputName = document.getElementById('input-name');
    const inputEmail = document.getElementById('input-email');
    const inputEmp = document.getElementById('input-employee-id');
    const inputRole = document.getElementById('input-role');

    if (nameEl) nameEl.innerText = defaultUser.name;
    if (roleEl) roleEl.innerText = defaultUser.role;
    if (avatarEl) avatarEl.innerText = getInitials(defaultUser.name);
    if (inputName) inputName.value = defaultUser.name;
    if (inputEmail) inputEmail.value = defaultUser.email;
    if (inputEmp) inputEmp.value = defaultUser.employeeId;
    if (inputRole) inputRole.value = defaultUser.role;

    const form = document.getElementById('personal-info-form');
    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const updatedUser = {
                name: inputName.value,
                email: inputEmail.value,
                role: inputRole.value,
                employeeId: inputEmp.value
            };

            try {
                const response = await fetch(`${API_BASE_URL}/update_profile`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ user_id: USER_ID, full_name: updatedUser.name, email: updatedUser.email })
                });
                const data = await response.json();
                if (data.status === 'success') {
                    localStorage.setItem('user', JSON.stringify(updatedUser));
                    alert("Profile updated successfully!");
                    location.reload();
                }
            } catch (error) {
                console.error("Error updating profile:", error);
                alert("Failed to update profile.");
            }
        });
    }
}

/* --- Role & Permissions Logic --- */
function initRolePermissions() {
    console.log("[RP] Initializing Role & Permissions...");
    const storedUser = JSON.parse(localStorage.getItem('user')) || {
        role: "Senior Administrator",
        employeeId: "GOI-78291"
    };
    const badge = document.getElementById('current-role-badge');
    const eid = document.querySelector('.role-id');
    if (badge) badge.innerText = storedUser.role;
    if (eid) eid.innerText = `Employee ID: ${storedUser.employeeId}`;
}

/* --- Preferences Logic --- */
function initPreferences() {
    console.log("[PREF] Initializing Preferences...");
    const darkModeToggle = document.getElementById('dark-mode-toggle');
    const autoSaveToggle = document.getElementById('autosave-toggle');
    const languageSelect = document.getElementById('language-select');

    const prefs = JSON.parse(localStorage.getItem('preferences')) || {
        darkMode: false,
        autoSave: true,
        language: 'en'
    };

    if (darkModeToggle) darkModeToggle.checked = prefs.darkMode;
    if (autoSaveToggle) autoSaveToggle.checked = prefs.autoSave;
    if (languageSelect) languageSelect.value = prefs.language;

    const saveBtn = document.getElementById('btn-save-prefs');
    if (saveBtn) {
        saveBtn.addEventListener('click', () => {
            const newPrefs = {
                darkMode: darkModeToggle.checked,
                autoSave: autoSaveToggle.checked,
                language: languageSelect.value
            };
            localStorage.setItem('preferences', JSON.stringify(newPrefs));
            alert("Preferences saved!");
        });
    }
}

/* --- Security Settings Logic --- */
async function initSecuritySettings() {
    console.log("[SEC] Initializing Security...");
    const btnToggle2FA = document.getElementById('btn-toggle-2fa');
    const status2FA = document.getElementById('2fa-status');
    const btnText2FA = document.getElementById('2fa-btn-text');

    let is2FAEnabled = false; 

    // TODO: Init 2FA status from backend
    
    if (btnToggle2FA) {
        btnToggle2FA.addEventListener('click', async () => {
            try {
                const response = await fetch(`${API_BASE_URL}/update_2fa`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ user_id: USER_ID, is_2fa_enabled: !is2FAEnabled })
                });
                const data = await response.json();
                if (data.status === 'success') {
                    is2FAEnabled = !is2FAEnabled;
                    if (status2FA) {
                        status2FA.innerText = is2FAEnabled ? "Enabled" : "Disabled";
                        status2FA.classList.toggle('active', is2FAEnabled);
                    }
                    if (btnText2FA) btnText2FA.innerText = is2FAEnabled ? "Disable 2FA" : "Enable 2FA";
                    alert(data.message);
                }
            } catch (error) {
                console.error("Error updating 2FA:", error);
            }
        });
    }

    // Device List Fetch
    const deviceList = document.getElementById('device-list');
    if (deviceList) {
        try {
            const response = await fetch(`${API_BASE_URL}/get_user_devices/${USER_ID}`);
            const data = await response.json();
            if (data.status === 'success') {
                deviceList.innerHTML = data.devices.map(device => `
                    <div class="permission-item">
                        <div class="perm-icon" style="background: rgba(26, 27, 75, 0.05); color: var(--primary);">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect><line x1="12" y1="18" x2="12.01" y2="18"></line></svg>
                        </div>
                        <div class="perm-text">
                            <h4>${device.device_info}</h4>
                            <p>Last login: ${device.last_login}</p>
                        </div>
                    </div>
                `).join('');
            }
        } catch (error) {
            console.error("Error fetching devices:", error);
            deviceList.innerHTML = '<p>Failed to load device history.</p>';
        }
    }
}

/* --- Privacy Settings Logic --- */
function initPrivacySettings() {
    console.log("[PRIV] Initializing Privacy...");
    const btnDelete = document.getElementById('btn-delete-account');
    const modal = document.getElementById('delete-modal');
    const cancelBtn = document.getElementById('modal-cancel');
    const confirmBtn = document.getElementById('modal-confirm-delete');

    if (btnDelete) btnDelete.addEventListener('click', () => modal.classList.remove('hidden'));
    if (cancelBtn) cancelBtn.addEventListener('click', () => modal.classList.add('hidden'));

    if (confirmBtn) {
        confirmBtn.addEventListener('click', async () => {
            try {
                const response = await fetch(`${API_BASE_URL}/delete_account/${USER_ID}`, {
                    method: 'DELETE'
                });
                const data = await response.json();
                if (data.status === 'success') {
                    alert("Account deleted permanently.");
                    window.location.href = 'index.html';
                }
            } catch (error) {
                console.error("Error deleting account:", error);
                alert("Failed to delete account.");
            }
        });
    }
}

/* --- Notifications Page Logic --- */
async function initNotificationsSettings() {
    console.log("[NOTIFY] Initializing Notifications Listing...");
    const listEl = document.getElementById('notifications-list');
    if (!listEl) return;

    try {
        const response = await fetch(`${API_BASE_URL}/notifications/${USER_ID}`);
        const data = await response.json();
        if (data.status === 'success') {
            if (data.notifications.length === 0) {
                listEl.innerHTML = '<p style="text-align:center; padding:50px; color:#64748b;">No notifications found.</p>';
                return;
            }

            listEl.innerHTML = data.notifications.map(n => `
                <div class="notification-card ${n.is_read ? '' : 'unread'}">
                    <div class="notify-icon-bg">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
                    </div>
                    <div class="notify-content">
                        <div class="notify-header">
                            <h4>${n.title}</h4>
                            <span class="notify-time">${n.timestamp}</span>
                        </div>
                        <p class="notify-body">${n.message}</p>
                    </div>
                </div>
            `).join('');
        }
    } catch (error) {
        console.error("Error fetching notifications:", error);
        listEl.innerHTML = '<p style="text-align:center; padding:50px; color:#ef4444;">Error loading notifications.</p>';
    }

    const markReadBtn = document.getElementById('btn-mark-all-read');
    if (markReadBtn) {
        markReadBtn.addEventListener('click', async () => {
            try {
                const response = await fetch(`${API_BASE_URL}/notifications/mark_read`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ user_id: USER_ID })
                });
                const data = await response.json();
                if (data.status === 'success') {
                    location.reload();
                }
            } catch (error) {
                console.error("Error marking as read:", error);
            }
        });
    }
}

/* --- Authentication Logic --- */

function initLogin() {
    console.log("[Auth] Initializing Login...");
    const form = document.getElementById('login-form');
    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            
            const btn = form.querySelector('button');
            btn.disabled = true;
            btn.innerText = "Signing In...";

            try {
                const response = await fetch(`${API_BASE_URL}/signin`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, password, device_name: "Web Portal", os_version: "Windows/Web" })
                });

                const data = await response.json();

                if (data.status === "success") {
                    localStorage.setItem('user', JSON.stringify(data.user));
                    showToast("Login successful! Redirecting...");
                    setTimeout(() => {
                        window.location.href = 'dashboard.html';
                    }, 1000);
                } else if (data.status === "2fa_required") {
                    // Handle 2FA if needed, for now just show error that Web 2FA is coming soon
                    showToast("2FA Required. Please use the mobile app to verify.");
                    btn.disabled = false;
                    btn.innerText = "Sign In";
                } else {
                    showToast(data.message || "Invalid credentials.");
                    btn.disabled = false;
                    btn.innerText = "Sign In";
                }
            } catch (error) {
                console.error("Login error:", error);
                showToast("Server connection failed. Is the backend running?");
                btn.disabled = false;
                btn.innerText = "Sign In";
            }
        });
    }
}

function initSignup() {
    console.log("[Auth] Initializing Signup...");
    const form = document.getElementById('signup-form');
    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const role = document.getElementById('role').value;
            const empId = document.getElementById('employeeId').value;
            const password = document.getElementById('password').value;
            
            const btn = form.querySelector('button');
            btn.disabled = true;
            btn.innerText = "Creating Account...";

            try {
                const response = await fetch(`${API_BASE_URL}/signup`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                        name, email, password, 
                        employee_id: empId, 
                        role: role 
                    })
                });

                const data = await response.json();

                if (data.status === "success") {
                    showToast("Account created successfully!");
                    setTimeout(() => {
                        window.location.href = 'login.html';
                    }, 1500);
                } else {
                    showToast(data.message || "Registration failed.");
                    btn.disabled = false;
                    btn.innerText = "Create Account";
                }
            } catch (error) {
                console.error("Signup error:", error);
                showToast("Server connection failed.");
                btn.disabled = false;
                btn.innerText = "Create Account";
            }
        });
    }
}

function initForgotPassword() {
    console.log("[Auth] Initializing Forgot Password...");
    
    // Step 1 Elements
    const requestForm = document.getElementById('forgot-password-form');
    const emailInput = document.getElementById('email');
    
    // Step 2 Elements
    const verifyForm = document.getElementById('otp-verify-form');
    const otpInput = document.getElementById('otp');
    const emailDisplay = document.getElementById('user-email-display');
    
    // Step 3 Elements
    const resetForm = document.getElementById('reset-password-form');
    const newPasswordInput = document.getElementById('new-password');
    
    // Final Step Elements
    const successMsg = document.getElementById('reset-success');
    let userEmail = "";

    // Handler for Step 1: Request OTP
    if (requestForm) {
        requestForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            userEmail = emailInput.value;
            const btn = requestForm.querySelector('button');
            btn.disabled = true;
            btn.innerText = "Sending Code...";

            try {
                const response = await fetch(`${API_BASE_URL}/forgot_password`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email: userEmail })
                });
                const data = await response.json();
                
                if (data.status === "success") {
                    showToast("Security code sent!");
                    requestForm.classList.add('hidden');
                    verifyForm.classList.remove('hidden');
                    if (emailDisplay) emailDisplay.innerText = userEmail;
                } else {
                    showToast(data.message || "Error sending code.");
                    btn.disabled = false;
                    btn.innerText = "Send Recovery Email";
                }
            } catch (error) {
                showToast("Server connection failed.");
                btn.disabled = false;
                btn.innerText = "Send Recovery Email";
            }
        });
    }

    // Handler for Step 2: Verify OTP
    if (verifyForm) {
        verifyForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const otp = otpInput.value;
            const btn = verifyForm.querySelector('button');
            btn.disabled = true;
            btn.innerText = "Verifying...";

            try {
                const response = await fetch(`${API_BASE_URL}/verify_otp`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email: userEmail, otp: otp })
                });
                const data = await response.json();

                if (data.status === "success") {
                    showToast("Code verified!");
                    verifyForm.classList.add('hidden');
                    resetForm.classList.remove('hidden');
                } else {
                    showToast(data.message || "Invalid or expired code.");
                    btn.disabled = false;
                    btn.innerText = "Verify Code";
                }
            } catch (error) {
                showToast("Connection failed.");
                btn.disabled = false;
                btn.innerText = "Verify Code";
            }
        });
    }

    // Handler for Step 3: Reset Password
    if (resetForm) {
        resetForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const newPassword = newPasswordInput.value;
            const btn = resetForm.querySelector('button');
            btn.disabled = true;
            btn.innerText = "Updating...";

            try {
                const response = await fetch(`${API_BASE_URL}/reset_password`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email: userEmail, new_password: newPassword })
                });
                const data = await response.json();

                if (data.status === "success") {
                    showToast("Password updated!");
                    resetForm.classList.add('hidden');
                    successMsg.classList.remove('hidden');
                } else {
                    showToast(data.message || "Error resetting password.");
                    btn.disabled = false;
                    btn.innerText = "Reset Password";
                }
            } catch (error) {
                showToast("Connection failed.");
                btn.disabled = false;
                btn.innerText = "Reset Password";
            }
        });
    }
}

function showToast(message) {
    // Create toast container if not exists
    let toastContainer = document.getElementById('toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.id = 'toast-container';
        document.body.appendChild(toastContainer);
    }
    
    const toast = document.createElement('div');
    toast.className = 'toast-message';
    toast.innerText = message;
    toastContainer.appendChild(toast);
    
    // Animate in
    setTimeout(() => {
        toast.style.opacity = '1';
        toast.style.transform = 'translateY(0)';
    }, 100);
    
    // Auto remove
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(20px)';
        setTimeout(() => toast.remove(), 500);
    }, 4000);
}
